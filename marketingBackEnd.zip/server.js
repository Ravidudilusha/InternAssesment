
const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");
const dotenv = require('dotenv')
const app = express();
const couponRouter = require("./api/routes/coupon");

const PORT = process.env.PORT || 8070;

app.use(cors());
app.use(bodyParser.json());
app.use("/coupon", couponRouter);

const CONNECTION_URL = "mongodb+srv://itp-project-2022:itp-pjt123@itp.fwlp6df.mongodb.net/?retryWrites=true&w=majority";
const URL = process.env.MONGODB_URL;
console.log(CONNECTION_URL);
mongoose.connect(CONNECTION_URL);
const connection = mongoose.connection;
connection.once("open", () => {
  console.log("MongoDB connection success!");
});

app.listen(PORT, () => {
  console.log(`Server is up and running on port ${PORT}`);
});
