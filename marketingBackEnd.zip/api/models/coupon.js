const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const CouponSchema = new Schema({
    code: {type: String, required: true},
    amount: {type: String, required: true },
    applyOn: {type: String, required: true },
    startDate: {type: String, required: true },
    endDate: {type: String, required: true }
});


module.exports = mongoose.model('Coupon', CouponSchema);
