const express = require("express");
const router = express.Router();
const Coupon = require("../models/coupon.js");


//Create
router.route("/add").post(async(req,res) => {
    const code = req.body.code;
    const amount = req.body.amount;
    const applyOn = req.body.applyOn;
    const startDate = req.body.startDate;
    const endDate = req.body.endDate;

    const newCoupon = new Coupon({
        code,
        amount,
        applyOn,
        startDate,
        endDate
    });

    await newCoupon.save()
    .then(() => {
        res.json("Coupon Added");
    })
    .catch((err) => {
        console.log(err);
    });
});


//Read all
router.route("/").get(async(req,res) => {
    await Coupon.find()
    .then((coupons) => {
        res.json(coupons);
    })
    .catch((err) => {
        console.log(err);
    });
});

//Update
router.route("/update/:id").put(async(req,res) => {
    let couponId = req.params.id;
    
    const code = req.body.code;
    const amount = req.body.amount;
    const applyOn = req.body.applyOn;
    const startDate = req.body.startDate;
    const endDate = req.body.endDate;
    
    const updateCoupon = {
        code,
        amount,
        applyOn,
        startDate,
        endDate
    }

    await Coupon.findByIdAndUpdate(couponId,updateCoupon)
    .then(() => {
        res.status(200).send({status: "Coupon updated"});
    })
    .catch((err) => {
        res.status(500).send({status: "Error with updating data", error: err.message});
    });
});


//Delete
router.route("/delete/:id").delete(async(req,res) => {
    let couponId = req.params.id;
    
    await Coupon.findByIdAndDelete(couponId)
    .then(() => {
        res.status(200).send({status: "Coupon deleted"});
    })
    .catch((err) => {
        res.status(500).send({status: "Error with delete user", error: err.message});
    });
});

module.exports = router;

// const express = require("express");
// const router = express.Router();
// const mongoose = require("mongoose");

// const Coupon = require("../models/coupon");

// router.get("/", (req, res, next) => {
//   Coupon.find()
//     .exec()
//     .then(docs => {
//       console.log(docs);
//       //   if (docs.length >= 0) {
//       res.status(200).json(docs);
//       //   } else {
//       //       res.status(404).json({
//       //           message: 'No entries found'
//       //       });
//       //   }
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({
//         error: err
//       });
//     });
// });

// router.post("/", (req, res, next) => {
//   const coupon = new Coupon({
//     _id: new mongoose.Types.ObjectId(),
//      code: req.body.code,
//      amount: req.body.amount,
//      applyOn: req.body.applyOn,
//      startDate: req.body.startDate,
//      endDate: req.body.endDate,
//   });
//   coupon
//     .save()
//     .then(result => {
//       console.log(result);
//       res.status(201).json({
//         message: "Coupon added!",
//         createdCoupon: result
//       });
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({
//         error: err
//       });
//     });
// });

// router.get("/:couponId", (req, res, next) => {
//   const id = req.params.couponId;
//   Coupon.findById(id)
//     .exec()
//     .then(doc => {
//       console.log("From database", doc);
//       if (doc) {
//         res.status(200).json(doc);
//       } else {
//         res
//           .status(404)
//           .json({ message: "No valid entry found for provided ID" });
//       }
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({ error: err });
//     });
// });

// router.patch("/:couponId", (req, res, next) => {
//   const id = req.params.couponId;
//   const updateOps = {};
//   for (const ops of req.body) {
//     updateOps[ops.propName] = ops.value;
//   }
//   Product.update({ _id: id }, { $set: updateOps })
//     .exec()
//     .then(result => {
//       console.log(result);
//       res.status(200).json(result);
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({
//         error: err
//       });
//     });
// });

// router.delete("/:couponId", (req, res, next) => {
//   const id = req.params.couponId;
//   Product.remove({ _id: id })
//     .exec()
//     .then(result => {
//       res.status(200).json(result);
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({
//         error: err
//       });
//     });
// });

// module.exports = router;