const express = require("express");
const router = express.Router();
const Order = require("../models/order.js");

//Create
router.route("/add").post(async(req,res) => {
    const orderId = req.body.orderId;
    const date = req.body.date;
    const phone = req.body.phone;
    const cusName = req.body.cusName;
    const location = req.body.location;
    const amount = req.body.amount;
    const status = req.body.status;

    const newOrder = new Order({
        orderId,
        date,
        phone,
        cusName,
        location,
        amount,
        status
    });

    await newOrder.save()
    .then(() => {
        res.json("Order Added");
    })
    .catch((err) => {
        console.log(err);
    });
});


//Read all
router.route("/").get(async(req,res) => {
    await Order.find()
    .then((orders) => {
        res.json(orders);
    })
    .catch((err) => {
        console.log(err);
    });
});

//Update
router.route("/update/:id").put(async(req,res) => {
    let orderID = req.params.id;
    
    const orderId = req.body.orderId;
    const date = req.body.date;
    const phone = req.body.phone;
    const cusName = req.body.cusName;
    const location = req.body.location;
    const amount = req.body.amount;
    const status = req.body.status;
    
    const updateOrder = {
        orderId,
        date,
        phone,
        cusName,
        location,
        amount,
        status
    }

    await Order.findByIdAndUpdate(orderID,updateOrder)
    .then(() => {
        res.status(200).send({status: "Order updated"});
    })
    .catch((err) => {
        res.status(500).send({status: "Error with updating data", error: err.message});
    });
});


//Delete
router.route("/delete/:id").delete(async(req,res) => {
    let orderID = req.params.id;
    
    await Order.findByIdAndDelete(orderID)
    .then(() => {
        res.status(200).send({status: "Order deleted"});
    })
    .catch((err) => {
        res.status(500).send({status: "Error with delete order", error: err.message});
    });
});

module.exports = router;

// const express = require("express");
// const router = express.Router();
// const mongoose = require("mongoose");

// const Coupon = require("../models/coupon");

// router.get("/", (req, res, next) => {
//   Coupon.find()
//     .exec()
//     .then(docs => {
//       console.log(docs);
//       //   if (docs.length >= 0) {
//       res.status(200).json(docs);
//       //   } else {
//       //       res.status(404).json({
//       //           message: 'No entries found'
//       //       });
//       //   }
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({
//         error: err
//       });
//     });
// });

// router.post("/", (req, res, next) => {
//   const coupon = new Coupon({
//     _id: new mongoose.Types.ObjectId(),
//      code: req.body.code,
//      amount: req.body.amount,
//      applyOn: req.body.applyOn,
//      startDate: req.body.startDate,
//      endDate: req.body.endDate,
//   });
//   coupon
//     .save()
//     .then(result => {
//       console.log(result);
//       res.status(201).json({
//         message: "Coupon added!",
//         createdCoupon: result
//       });
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({
//         error: err
//       });
//     });
// });

// router.get("/:couponId", (req, res, next) => {
//   const id = req.params.couponId;
//   Coupon.findById(id)
//     .exec()
//     .then(doc => {
//       console.log("From database", doc);
//       if (doc) {
//         res.status(200).json(doc);
//       } else {
//         res
//           .status(404)
//           .json({ message: "No valid entry found for provided ID" });
//       }
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({ error: err });
//     });
// });

// router.patch("/:couponId", (req, res, next) => {
//   const id = req.params.couponId;
//   const updateOps = {};
//   for (const ops of req.body) {
//     updateOps[ops.propName] = ops.value;
//   }
//   Product.update({ _id: id }, { $set: updateOps })
//     .exec()
//     .then(result => {
//       console.log(result);
//       res.status(200).json(result);
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({
//         error: err
//       });
//     });
// });

// router.delete("/:couponId", (req, res, next) => {
//   const id = req.params.couponId;
//   Product.remove({ _id: id })
//     .exec()
//     .then(result => {
//       res.status(200).json(result);
//     })
//     .catch(err => {
//       console.log(err);
//       res.status(500).json({
//         error: err
//       });
//     });
// });

// module.exports = router;