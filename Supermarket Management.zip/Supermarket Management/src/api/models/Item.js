const mongoose =  require('mongoose');

const Schema = mongoose.Schema;

const itemSchema = new Schema({
    name : {
        type : String,
        required: true
    },
    itemNo:{
        type: Number,
        required: true
    },
    Type:{
        type: String,
        required: true
    },
    Availability:{
        type: Number,
        required: true
    },
    Reserved:{
        type: Number,
        required:true
    },
    Price:{
        type: Number,
        required:true
    }
})

const Item = mongoose.model("Item",itemSchema);
module.exports = Item;