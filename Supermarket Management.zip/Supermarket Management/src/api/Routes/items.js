const router = require("express").Router();
const { response } = require("express");
let Item = require("../models/Item");


router.route("/add").post((req,res) =>{

    const name = req.body.name;
    const itemNo = Number(req.body.itemNo);
    const Type = req.body.Type;
    const Availability = Number(req.body.Availability);
    const Reserved = Number(req.body.Reserved);
    const  Price = Number(req.body.Price);

    const newItem = new Item({
        name,
        itemNo,
        Type,
        Availability,
        Reserved,
        Price
    })

    newItem.save().then(() => {
        res.json("Item added");
    }).catch((err)=>{
        console.log(err);
    })

})

router.route("/").get((req,res) =>{

    Item.find().then((items)=>{
        res.json(items);
    }).catch((err)=>{
        console.log(err);
    })

})

router.route("/update/:id").put(async(req,res) =>{
    let userId = req.params.id;
    const {name, itemNo, Type, Availability, Reserved, Price} = req.body;

    const updateItem = {
        name,
        itemNo,
        Type,
        Availability,
        Reserved,
        Price
    }

    const update = await Item.findByIdAndUpdate(userId,updateItem).then(() =>{
        res.status(200).send({status: "Item Updated", user: update});

    }).catch((err) =>{
        console.log(err);
        res.status(500).send({status: "Error with updating data", error: err.message});
    })

})

router.route("/delete/:id").delete(async (req,res) =>{
    let userId = req.params.id;

    await Item.findByIdAndDelete(userId).then(() =>{
        res.status(200).send({status: "Item Deleted"});
    }).catch((err) =>{
        console.log(err.message);
        res.status(500).send({status: "Error with deleting item", error: err.message});
    })

})

router.route("/get/:id").get(async (req,res) =>{
    let userId = req.params.id;
    const user = await Item.findById(userId).then((item) =>{
        res.status(200).send({status: "Item Fetched", item});
    }).catch(() =>{
        console.log(err.message);
        res.status(500).send({status: "Error with get Item",error: err.message});
    })
})

module.exports = router;