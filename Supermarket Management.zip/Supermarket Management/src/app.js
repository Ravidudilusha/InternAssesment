import express from "express";
import cors from "cors";
import logger from "./utils/logger"; 
import "dotenv/config";
import {connect} from "./utils/database.connection";

const app = express();
const PORT = process.env.PORT || "5000";

app.use(cors());
app.use(express.json({ limit: "20mb"}));

app.get("/" , (req,res,next) => {
    res.send("<h2> Supermarket Management System</h2>");
    next();
});

const itemRouter = require("./api/Routes/items");

app.use("/item",itemRouter );


app.listen(PORT, () => {
  
    console.log(`Server is up and running on PORT ${PORT}`);
    connect();
});
